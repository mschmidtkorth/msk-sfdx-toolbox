# Changelog
## 0.0.1
- Initial release

### Added
- Support for comparing permissions

## 0.0.2
### Added
- Support for opening Scratch Orgs
- Setting to define default working directory

## 0.0.3
### Added
- Keyboard shortcuts and context bindings to improve UX
- Actions on notification messages

### Removed
- `msk.listPermissions` which is included in `msk.comparePermissions`